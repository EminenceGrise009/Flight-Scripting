package com.example.flight.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PlaceWithAirportDb {
    Long id;
    String place;
    String placeNickName;
    List<String> airports;
}
