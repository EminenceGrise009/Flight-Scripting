package com.example.flight.entity.master;


import com.example.flight.entity.base.AuditSupport;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import static com.example.flight.constant.TableName.AIRPORTS;

@Getter
@Setter
@Table(name = AIRPORTS)
@Entity
@DynamicUpdate
@FieldNameConstants(level = AccessLevel.PUBLIC)
public class Airport extends AuditSupport {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "airports_gen")
    @SequenceGenerator(name = "airports_gen", sequenceName = "airports_seq")
    @Column(name = "id", nullable = false)
    @JdbcTypeCode(SqlTypes.BIGINT)
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "status", nullable = false)
    private Boolean status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "place_id", nullable = false)
    private Place place;

}
