package com.example.flight.entity.master;

import com.example.flight.entity.base.AuditSupport;
import com.example.flight.entity.embedded.NickName;
import io.hypersistence.utils.hibernate.type.json.JsonType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.Type;
import org.hibernate.type.SqlTypes;

import java.util.List;
import java.util.Set;

import static com.example.flight.constant.TableName.COUNTRIES;

@Getter
@Setter
@Table(name = COUNTRIES)
@Entity
@DynamicUpdate

public class Country extends AuditSupport {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "countries_gen")
    @SequenceGenerator(name = "countries_gen", sequenceName = "countries_seq")
    @Column(name = "id", nullable = false)
    @JdbcTypeCode(SqlTypes.BIGINT)
    private Long id;

    @Column(name = "name", nullable = false, length = 100, unique = true)
    private String name;

    @Column(name = "status", nullable = false)
    private Boolean status;

    @Type(JsonType.class)
    @Column(name = "nick_names", columnDefinition = "jsonb")
    private Set<NickName> nickNames;

    @OneToMany(mappedBy = Place.Fields.country, fetch = FetchType.LAZY)
    private List<Place> places;

    @OneToMany(mappedBy = State.Fields.country, fetch = FetchType.LAZY)
    private List<State> states;

}
