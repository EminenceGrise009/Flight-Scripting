package com.example.flight.constant;

public enum TravelServiceCategory {
    FLIGHT,
    HOTEL,
    BUS
}
