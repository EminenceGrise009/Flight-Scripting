package com.example.flight.constant;

public class TableName {
    public static final String AIRPORTS = "airports";
    public static final String COUNTRIES = "countries";
    public static final String STATES = "states";
    public static final String PLACES = "places";
}
