package com.example.flight.service;


import com.example.flight.dto.CountryWithPlace;
import com.example.flight.dto.PlaceWithAirport;
import com.opencsv.CSVReader;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

@Service
public class CSVReaderService {

    public Map<String, CountryWithPlace> readFile() throws IOException {
        ClassPathResource cpr = new ClassPathResource("files/airport");
        File file = cpr.getFile();
        return getCsvData(file);
    }

    public static Map<String, CountryWithPlace> getCsvData(File file) {
        try {
            FileReader filereader = new FileReader(file);
            CSVReader csvReader = new CSVReader(filereader);
            String[] row;

            Map<String, CountryWithPlace> countryNameMappedByCountryData = new HashMap<>();

            while ((row = csvReader.readNext()) != null) {  // 1
                long linesRead = csvReader.getLinesRead();
                if (Objects.equals(linesRead, 1L)) {
                    continue;
                }
                String countryName = row[7];
                String placeName = row[4];
                String airportName = row[1];
                String placeNickName=row[2];
                String countryNickName=row[3];
                CountryWithPlace countryData = getCsvObject(countryName, placeName, airportName,placeNickName,countryNickName);
                groupByCountry(countryNameMappedByCountryData, countryName,countryNickName,placeNickName, placeName, airportName, countryData);
            }
            return countryNameMappedByCountryData;
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    private static void groupByCountry(Map<String, CountryWithPlace> countryNameMappedByCountryData, String countryName,String countryNickName,String placeNickName,  String placeName, String airportName, CountryWithPlace countryData) {
        if(countryNameMappedByCountryData.containsKey(countryName)){
            CountryWithPlace alreadyExistCountryData = countryNameMappedByCountryData.get(countryName);
            alreadyExistCountryData.setCountryNickName(countryNickName);
            Map<String, PlaceWithAirport> placeNameMappedByPlaceData = alreadyExistCountryData.getPlaceNameMappedByPlaceData();
            groupByPlace(placeName, placeNickName,airportName, placeNameMappedByPlaceData);

        }else {
            countryNameMappedByCountryData.put(countryName, countryData);
        }
    }

    private static void groupByPlace(String placeName,String placeNickName, String airportName, Map<String, PlaceWithAirport> placeNameMappedByPlaceData) {
        if(placeNameMappedByPlaceData.containsKey(placeName)){
            System.out.println("multiple airport finded ** "+ placeName + " ## " + airportName);
            PlaceWithAirport placeWithAirport = placeNameMappedByPlaceData.get(placeName);
            placeWithAirport.setPlaceNickName(placeNickName);
            List<String> airports = placeWithAirport.getAirports();
            airports.add(airportName);
        }else {
            PlaceWithAirport placeWithAirport = new PlaceWithAirport();
            placeWithAirport.setPlaceName(placeName);
            placeWithAirport.setPlaceNickName(placeNickName);
            List<String> airports = new ArrayList<>();
            airports.add(airportName);
            placeWithAirport.setAirports(airports);
            placeNameMappedByPlaceData.put(placeName, placeWithAirport);
        }
    }

    private static CountryWithPlace getCsvObject(String countryCell, String placeCell, String airportCell,String placeNickNameCell,String countryNickNameCell) {
        CountryWithPlace countryWithPlace = new CountryWithPlace();
        countryWithPlace.setCountryName(countryCell);
        countryWithPlace.setCountryNickName(countryNickNameCell);

        PlaceWithAirport placeWithAirport = new PlaceWithAirport();
        placeWithAirport.setPlaceName(placeCell);
        placeWithAirport.setPlaceNickName(placeNickNameCell);

        List<String> airportList = new ArrayList<>();
        airportList.add(airportCell);

        placeWithAirport.setAirports(airportList);

        Map<String, PlaceWithAirport> placeNameMappedByPlaceData = new HashMap<>();
        placeNameMappedByPlaceData.put(placeCell, placeWithAirport);

        countryWithPlace.setPlaceNameMappedByPlaceData(placeNameMappedByPlaceData);
        return countryWithPlace;
    }





}

