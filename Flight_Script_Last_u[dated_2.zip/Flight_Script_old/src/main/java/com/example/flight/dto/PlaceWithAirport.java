package com.example.flight.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PlaceWithAirport {
    String placeName;
    String placeNickName;
    List<String> airports;
}