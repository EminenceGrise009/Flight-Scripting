package com.example.flight.entity.embedded;

import com.example.flight.constant.TravelServiceCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NickName implements Serializable {
    @Serial
    private static final long serialVersionUID = 1_3004L;

    private String name;

    @Enumerated(EnumType.STRING)
    private TravelServiceCategory travelCategory;

    private String supplierName;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NickName nickName1 = (NickName) o;
        return Objects.equals(name, nickName1.name) && travelCategory == nickName1.travelCategory && Objects.equals(supplierName, nickName1.supplierName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, travelCategory, supplierName);
    }

}