package com.example.flight.service;

import com.example.flight.dto.CountryWithPlaceDb;
import com.example.flight.dto.PlaceWithAirportDb;
import com.example.flight.entity.master.Country;
import com.example.flight.entity.master.Place;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DatabaseConverterService {

    public Map<String, CountryWithPlaceDb> getCountryFromDatabase(List<Country> all) {
        return getStringCountryWithPlaceDbMap(all);
    }

    private Map<String, CountryWithPlaceDb> getStringCountryWithPlaceDbMap(List<Country> all) {
        Map <String, CountryWithPlaceDb> countryMap = new HashMap<>();
        for (Country country : all){
            CountryWithPlaceDb countryWithPlaceDb = new CountryWithPlaceDb();

            String name = country.getName();
            boolean and = name.contains("&");
            if(and){
                name = name.replace("&", "and");
            }
            String lowerCase = name.toLowerCase();
            String trim = lowerCase.trim();

            String s = normalizedString(trim);
            countryWithPlaceDb.setCountry(s);
            countryWithPlaceDb.setId(country.getId());

            Map<String, PlaceWithAirportDb> placeWithAirportDbMap = getStringPlaceWithAirportDbMap(country);
            countryWithPlaceDb.setPlaceNameMappedByPlaceData(placeWithAirportDbMap);

            countryMap.put(s, countryWithPlaceDb);

        }
        return countryMap;
    }

    private Map<String, PlaceWithAirportDb> getStringPlaceWithAirportDbMap(Country country) {
        Map<String, PlaceWithAirportDb> placeWithAirportDbMap = new HashMap<>();
        for (Place place : country.getPlaces()) {
            PlaceWithAirportDb placeWithAirportDb = new PlaceWithAirportDb();
            placeWithAirportDb.setId(place.getId());

            String name = place.getName();
            boolean and = name.contains("&");
            if(and){
                name = name.replace("&", "and");
            }
            String lowerCase = name.toLowerCase();
            String trim = lowerCase.trim();
            String s = normalizedStringPlace(trim);
            placeWithAirportDb.setPlace(s);
            placeWithAirportDb.setAirports(List.of());
            placeWithAirportDbMap.put(s, placeWithAirportDb);
        }
        return placeWithAirportDbMap;
    }

    public String normalizedString(String s1) {
        // Remove all whitespace nd convert to lowercase
        return s1.replaceAll("\\s*\\([^)]*\\)\\s*", "").replaceAll("\\s+", "").toLowerCase();
    }

    public String normalizedStringPlace(String s1) {
        if(s1.equals("Brady - TX")){
            System.out.println("dfdfd");
        }
        s1 = s1.split("[-\\s]+")[0];
        // Remove all whitespace nd convert to lowercase
        return s1.replaceAll("\\s*\\([^)]*\\)\\s*", "").replaceAll("\\s+", "").toLowerCase();
    }
}
