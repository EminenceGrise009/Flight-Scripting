package com.example.flight.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class CountryWithPlace {
    String countryName;
    String countryNickName;
    Map<String, PlaceWithAirport> placeNameMappedByPlaceData;
}