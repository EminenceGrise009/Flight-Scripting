package com.example.flight.service;

import com.example.flight.constant.TravelServiceCategory;
import com.example.flight.dto.CountryWithPlace;
import com.example.flight.dto.CountryWithPlaceDb;
import com.example.flight.dto.PlaceWithAirport;
import com.example.flight.dto.PlaceWithAirportDb;
import com.example.flight.entity.embedded.NickName;
import com.example.flight.entity.master.Airport;
import com.example.flight.entity.master.Country;
import com.example.flight.entity.master.Place;
import com.example.flight.repository.AirportRepository;
import com.example.flight.repository.CountryRepository;
import com.example.flight.repository.PlaceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class DataDumpService {
    private final CSVReaderService csvReaderService;
    private final DatabaseConverterService databaseConverterService;
    private final CountryRepository countryRepository;
    private final PlaceRepository placeRepository;
    private final AirportRepository airportRepository;

    public DataDumpService(CSVReaderService csvReaderService, DatabaseConverterService databaseConverterService, CountryRepository countryRepository, PlaceRepository placeRepository, AirportRepository airportRepository) {
        this.csvReaderService = csvReaderService;
        this.databaseConverterService = databaseConverterService;
        this.countryRepository = countryRepository;
        this.placeRepository = placeRepository;
        this.airportRepository = airportRepository;
    }


    @Transactional
    public void dumpFlightData() throws IOException {

        List<Country> all = countryRepository.findAll();
        Map<Long, Country> countryMap = all.stream()
                .collect(Collectors.toMap(Country::getId, Function.identity()));

        Map<Long, Place> placeMap = placeRepository.findAll()
                .stream().collect(Collectors.toMap(Place::getId, Function.identity()));


        Map<String, CountryWithPlace> csvData =
                csvReaderService.readFile();

        Map<String, CountryWithPlaceDb> dataBaseData =
                databaseConverterService.getCountryFromDatabase(all);

        saveCountryIfExist(csvData, dataBaseData, placeMap, countryMap);
    }

    private void saveCountryIfExist(Map<String, CountryWithPlace> csvData,
                                    Map<String, CountryWithPlaceDb>
                                            dataBaseData, Map<Long, Place> placeMap,
                                    Map<Long, Country> countryMap) {
        csvData.forEach((countryKey, csvCountryValue) -> {

            boolean and = countryKey.contains("&");
            if(and){
                countryKey = countryKey.replace("&", "and");
            }
            String lowerCase = countryKey.toLowerCase();
            String trim = lowerCase.trim();
            String s = databaseConverterService.normalizedString(trim);
            CountryWithPlaceDb countryWithPlaceDb = dataBaseData.get(s); // india or null

            if (countryWithPlaceDb != null) {
                checkPlaceAndAirportExist(placeMap, countryMap, csvCountryValue, countryWithPlaceDb);
            } else {
                saveCountry(csvCountryValue);
            }
        });
    }

    private void saveCountry(CountryWithPlace csvCountryValue) {
        Country country = new Country();
        country.setName(csvCountryValue.getCountryName());
        country.setStatus(true);
        country.setNickNames(Set.of(new NickName(csvCountryValue.getCountryNickName(), TravelServiceCategory.FLIGHT, "INDIGO")));
        country.setCreatedBy(0L);
        country.setLastModifiedBy(0L);
        country.setCreatedDate(LocalDateTime.now());
        country.setLastModifiedDate(LocalDateTime.now());
        country.setVersion(0L);
        Country savedCountry = countryRepository.save(country);

        Map<String, PlaceWithAirport> placeNameMappedByPlaceData = csvCountryValue.getPlaceNameMappedByPlaceData();
        for (Map.Entry<String, PlaceWithAirport> entry : placeNameMappedByPlaceData.entrySet()) {
            savePlace(entry.getValue(), savedCountry);
        }
    }

    private void checkPlaceAndAirportExist(Map<Long, Place> placeMap, Map<Long, Country> countryMap,
                                           CountryWithPlace csvCountryValue,
                                           CountryWithPlaceDb countryWithPlaceDb) {
        Map<String, PlaceWithAirport> countryPlaceInCsv =
                csvCountryValue.getPlaceNameMappedByPlaceData(); // all place of india in Csv
        Map<String, PlaceWithAirportDb> countryPlaceInDb =
                countryWithPlaceDb.getPlaceNameMappedByPlaceData();

        countryPlaceInCsv.forEach((placeKey, csvPlaceValue) -> {
            boolean and = placeKey.contains("&");
            if(and){
                placeKey = placeKey.replace("&", "and");
            }
            String lowerCase = placeKey.toLowerCase();
            String trim = lowerCase.trim();
            String s = databaseConverterService.normalizedStringPlace(trim);
            PlaceWithAirportDb placeWithAirportDb = countryPlaceInDb.get(s);
            saveAirportWhenPlaceExist(csvPlaceValue, placeWithAirportDb, placeMap,
                    countryMap, countryWithPlaceDb, csvCountryValue);
        });
    }

    private void savePlace(PlaceWithAirport csvPlaceValue, Country savedCountry) {
        Place place = new Place();
        place.setName(csvPlaceValue.getPlaceName());
        place.setNickNames(Set.of(new NickName(csvPlaceValue.getPlaceNickName(), TravelServiceCategory.FLIGHT, "INDIGO")));
        place.setCountry(savedCountry);
        place.setCreatedBy(0L);
        place.setLastModifiedBy(0L);
        place.setCreatedDate(LocalDateTime.now());
        place.setLastModifiedDate(LocalDateTime.now());
        place.setVersion(0L);
        place.setStatus(true);
        Place save = placeRepository.save(place);
        saveAirport(csvPlaceValue, save);
    }

    private void saveAirportWhenPlaceExist(PlaceWithAirport csvPlaceValue,
                                           PlaceWithAirportDb placeWithAirportDb,
                                           Map<Long, Place> placeMap,
                                           Map<Long, Country> countryMap,
                                           CountryWithPlaceDb countryWithPlaceDb,
                                           CountryWithPlace csvCountryWithPlace) {
        Long countryId = countryWithPlaceDb.getId();
        Country country = countryMap.get(countryId);

        if (placeWithAirportDb != null) {
            Set<NickName> nickNames = country.getNickNames();
            NickName nickName = new NickName();
            String countryNickName = csvCountryWithPlace.getCountryNickName();
            nickName.setName(countryNickName);
            nickName.setSupplierName("INDIGO");
            nickName.setTravelCategory(TravelServiceCategory.FLIGHT);
            nickNames.add(nickName);
            country.setNickNames(nickNames);
            countryRepository.save(country);// update
            Place place = placeMap.get(placeWithAirportDb.getId());

            savePlaceWhenExist(csvPlaceValue, place);
        } else {
            savePlace(csvPlaceValue, country);
        }
    }

    private void savePlaceWhenExist(PlaceWithAirport csvPlaceValue, Place place) {

        Set<NickName> nickNames = place.getNickNames();
        Set<NickName> newList = new HashSet<>(nickNames);
        NickName nickName = new NickName();
        nickName.setName(csvPlaceValue.getPlaceNickName());
        nickName.setSupplierName("INDIGO");
        nickName.setTravelCategory(TravelServiceCategory.FLIGHT);
        newList.add(nickName);
        place.setNickNames(newList);
        placeRepository.save(place);// update


        saveAirport(csvPlaceValue, place);
    }

    private void saveAirport(PlaceWithAirport csvPlaceValue, Place place) {
        List<String> airports = csvPlaceValue.getAirports();
        for (String airportName : airports) {
            Airport airport = new Airport();
            airport.setName(airportName);
            airport.setStatus(true);
            airport.setCreatedBy(0L);
            airport.setLastModifiedBy(0L);
            airport.setCreatedDate(LocalDateTime.now());
            airport.setLastModifiedDate(LocalDateTime.now());
            airport.setVersion(0L);
            airport.setPlace(place);
            airportRepository.save(airport);
        }
    }

}
