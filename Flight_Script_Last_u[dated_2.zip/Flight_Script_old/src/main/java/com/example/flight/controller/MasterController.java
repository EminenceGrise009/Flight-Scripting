package com.example.flight.controller;


import com.example.flight.service.DataDumpService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/dump")
@RequiredArgsConstructor
public class MasterController {
   private final DataDumpService dataDumpService;

    @PostMapping("/dump-flight-data")
    public void dumpFlightDataIntoDatabase() throws IOException{
        System.out.printf("Started "+ LocalDateTime.now());
        dataDumpService.dumpFlightData();
        System.out.println("Ended "+ LocalDateTime.now());
    }

}

