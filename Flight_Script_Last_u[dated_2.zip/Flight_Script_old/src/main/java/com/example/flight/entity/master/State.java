package com.example.flight.entity.master;

import com.example.flight.entity.base.AuditSupport;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import static com.example.flight.constant.TableName.STATES;

@Getter
@Setter
@Table(name = STATES)
@Entity
@DynamicUpdate
@FieldNameConstants(level = AccessLevel.PUBLIC)

public class State extends AuditSupport {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "places_gen")
    @SequenceGenerator(name = "places_gen", sequenceName = "places_seq")
    @Column(name = "id", nullable = false)
    @JdbcTypeCode(SqlTypes.BIGINT)
    private Long id;

    @Column(name = "name", nullable = false, unique = true)
    private String name;

    @Column(name = "status", nullable = false)
    private Boolean status;

    @ManyToOne
    @JoinColumn(name = "countries", nullable = false)
    private Country country;

}
