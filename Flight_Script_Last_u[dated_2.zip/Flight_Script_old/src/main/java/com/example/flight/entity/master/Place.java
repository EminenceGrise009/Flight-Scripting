package com.example.flight.entity.master;

import com.example.flight.entity.base.AuditSupport;
import com.example.flight.entity.embedded.NickName;
import io.hypersistence.utils.hibernate.type.json.JsonType;
import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.Type;
import org.hibernate.type.SqlTypes;

import java.util.List;
import java.util.Set;

import static com.example.flight.constant.TableName.PLACES;

@Getter
@Setter
@Table(name = PLACES)
@Entity
@DynamicUpdate
@FieldNameConstants(level = AccessLevel.PUBLIC)
public class Place extends AuditSupport {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "places_gen")
    @SequenceGenerator(name = "places_gen", sequenceName = "places_seq")
    @Column(name = "id", nullable = false)
    @JdbcTypeCode(SqlTypes.BIGINT)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "status", nullable = false)
    private Boolean status;

    @Column(name = "nick_names", columnDefinition = "jsonb")
    @Type(JsonType.class)
    private Set<NickName> nickNames;

    @OneToMany(mappedBy = Airport.Fields.place, fetch = FetchType.LAZY)
    private List<Airport> airport;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "countries", nullable = false)
    private Country country;
}